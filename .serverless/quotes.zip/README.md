# IBFlexQueryAPIProxy
An API to allow making Flex Queries to Interactive Brokers using csingley's ibflex

Follow this guide to configure your Flex Queries in your Interactive Brokers account:

https://help.wealthica.com/help/how-to-connect-ib-interactive-brokers-and-configure-the-flex-report

| Headers |Description  |
|--|--|
|**IBKR-TOKEN**  | Your Token  |
|**IBKR-QUERY**  | Your Query ID |
